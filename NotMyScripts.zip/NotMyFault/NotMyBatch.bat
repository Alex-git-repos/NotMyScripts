@echo off
powershell.exe -NoExit -NoProfile -ExecutionPolicy Bypass -File "%~dpn0.ps1" %*
exit