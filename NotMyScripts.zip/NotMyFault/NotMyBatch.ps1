if (-Not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}

cd "$env:USERPROFILE\Downloads\NotMyFault"

.\notmyfaultc64.exe /accepteula /?

$args = Read-Host -Prompt "Enter arguments"
.\notmyfaultc64.exe /accepteula $args.Split(" ")